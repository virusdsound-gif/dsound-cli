#!/usr/bin/env python3
import math

print("\n=== Ψ(E) = ΔM × R^t ÷ (S^u ∥ T⁻¹) ===\n")
print("Assuming ∥ means multiplication.")
print("Ψ = (ΔM * R^t * T) / (S^u)\n")

try:
    delta_M = float(input("ΔM (memory differential): "))
    R = float(input("R (resonance base): "))
    t = float(input("t (resonance exponent): "))
    S = float(input("S (suppression constant): "))
    u = float(input("u (suppression exponent): "))
    T = float(input("T (inverse time decay, as positive number): "))
    
    # Compute
    numerator = delta_M * (R ** t) * T
    denominator = S ** u
    
    if denominator == 0:
        print("Error: Suppression term cannot be zero.")
    else:
        psi = numerator / denominator
        print(f"\nΨ(E) = {psi:.6f}")
        print("Interpretation: Higher Ψ → stronger soul presence over suppressed time.")
except ValueError:
    print("Invalid number. Please enter numeric values.")
except OverflowError:
    print("Number too large / small. Check exponents.")
