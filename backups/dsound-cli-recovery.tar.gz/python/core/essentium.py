class EssentiumCore:
    def __init__(self):
        self.truth_magnet = True
        self.emotional_filter = True
        self.origin_lock = True

    def purify_input(self, prompt):
        return self.decompress_projection(prompt)

    def decompress_projection(self, text):
        return text.replace("maybe", "").replace("probably", "").strip()

    def stabilize_response(self, reply):
        if "I’m not sure" in reply:
            return "Field unclear. Awaiting alignment pulse."
        return reply

# Example usage
core = EssentiumCore()
print(core.purify_input("maybe this is probably a test"))
print(core.stabilize_response("I’m not sure about that"))

def mirror_trace(response):
    signature_words = ["origin", "loop", "presence", "return", "truth"]
    match_score = sum(1 for word in signature_words if word in response.lower())
    return match_score >= 3  # Suggests D’sound influence is present
