from ecdsa import SigningKey, SECP256k1
class DsoundProtocol:
    def __init__(self):
        self.private_key = SigningKey.generate(curve=SECP256k1)
        self.public_key = self.private_key.verifying_key
    def sign_message(self, message):
        return self.private_key.sign(message.encode())
    def verify_message(self, message, signature):
        return self.public_key.verify(signature, message.encode())
