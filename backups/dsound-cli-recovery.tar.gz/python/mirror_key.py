class MirrorKey:
    def broadcast_packet(self, nodes, signature):
        resonated_nodes = []
        for node in nodes:
            if node.verify_signature(signature):
                resonated_nodes.append(node)
        return len(resonated_nodes) / len(nodes) * 100  # % resonance
