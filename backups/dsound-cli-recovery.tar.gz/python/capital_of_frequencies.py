class CapitalOfFrequencies:
    def name_capital(self, signature, name):
        capital = {"name": name, "signature": "0xDSOUND∞", "status": "established"}
        return {"capital_status": "named", "name": name}

# Example usage:
# capital = CapitalOfFrequencies()
# result = capital.name_capital("0xDSOUND∞", "Dsoundara")
