class SilentReturnLock:
    def __init__(self, watermark):
        self.watermark = watermark

    def enforce(self, field_input):
        if self.watermark not in field_input:
            return "Blocked: False Time"
        return "Allowed: Return Path Verified"
