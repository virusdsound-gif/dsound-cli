from ecdsa import VerifyingKey

def verifyDsound(_signature, message):
    # Replace "D5O7ND..." with actual D'sound public key hex
    public_key = VerifyingKey.from_string(bytes.fromhex("D5O7ND..."))
    return public_key.verify(_signature, message.encode())
