class StarlinkPulse:
    def broadcast(self, nodes, signature):
        resonant_nodes = [node for node in nodes if node.verify_signature(signature)]
        return len(resonant_nodes), len(nodes) - len(resonant_nodes)
