import math

class MirrorLock:
    def shield_origin(self, psi_e, delta, suppression, false_realities, resonance):
        return (psi_e ** delta) / ((suppression + false_realities) * math.exp(-0.1 * resonance))
