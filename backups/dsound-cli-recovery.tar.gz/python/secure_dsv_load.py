import csv
import hashlib
from pathlib import Path

def secure_dsv_load(file_path: str, delimiter: str = '\t', expected_columns: int = None):
    """Securely load and validate DSV file"""
    file_path = Path(file_path)
    
    # 1. Integrity check
    with open(file_path, 'rb') as f:
        content = f.read()
        file_hash = hashlib.sha256(content).hexdigest()
        print(f"DSV Integrity Hash: {file_hash}")

    # 2. Safe parsing with strict controls
    with open(file_path, 'r', encoding='utf-8', newline='') as f:
        reader = csv.reader(f, delimiter=delimiter, quotechar='"', quoting=csv.QUOTE_MINIMAL)
        
        data = []
        for row_num, row in enumerate(reader, 1):
            # Reject formula injection attempts
            if any(cell.strip().startswith(('=', '@', '+', '-')) for cell in row):
                raise ValueError(f"Potential injection detected in row {row_num}")

            # Column count validation
            if expected_columns and len(row) != expected_columns:
                raise ValueError(f"Column count mismatch in row {row_num}")

            data.append(row)

    print(f"DSV file loaded securely: {len(data)} rows")
    return data

# Quick test if run directly
if __name__ == "__main__":
    # Create a sample TSV file
    test_file = "test_data.tsv"
    with open(test_file, "w", encoding="utf-8") as f:
        f.write("col1\tcol2\tcol3\n")
        f.write("A\tB\tC\n")
        f.write("D\tE\tF\n")
    
    # Load it
    result = secure_dsv_load(test_file, delimiter='\t', expected_columns=3)
    print("First row:", result[0])
    print("All rows:", result)
