#!/usr/bin/env python3
"""
secure_dsv_loader.py - Optimized for Termux
Secure loading of delimiter-separated values with streaming.
"""

import csv
import hashlib
import sys
import argparse
from pathlib import Path
from typing import List, Optional, Generator, Any

def file_hash(path: Path, chunk_size: int = 8192) -> str:
    """Compute SHA256 hash of file using chunks (low memory)."""
    sha = hashlib.sha256()
    with open(path, 'rb') as f:
        while chunk := f.read(chunk_size):
            sha.update(chunk)
    return sha.hexdigest()

def stream_dsv(path: Path, delimiter: str = '\t',
               expected_columns: Optional[int] = None) -> Generator[List[str], None, None]:
    """
    Stream rows securely from DSV file.
    Yields each row as list of strings.
    """
    with open(path, 'r', encoding='utf-8', newline='') as f:
        reader = csv.reader(f, delimiter=delimiter, quotechar='"',
                            quoting=csv.QUOTE_MINIMAL)
        for row_num, row in enumerate(reader, 1):
            # Reject formula injection
            if any(cell.strip().startswith(('=', '@', '+', '-')) for cell in row):
                raise ValueError(f"Injection detected at row {row_num}: {row}")
            if expected_columns and len(row) != expected_columns:
                raise ValueError(f"Column mismatch row {row_num}: expected {expected_columns}, got {len(row)}")
            yield row

def load_dsv(file_path: str, delimiter: str = '\t',
             expected_columns: Optional[int] = None) -> List[List[str]]:
    """Full load with integrity check (returns all rows)."""
    path = Path(file_path)
    if not path.exists():
        raise FileNotFoundError(f"File not found: {file_path}")

    print(f"Integrity SHA256: {file_hash(path)}", file=sys.stderr)

    rows = []
    for row in stream_dsv(path, delimiter, expected_columns):
        rows.append(row)

    print(f"Loaded {len(rows)} rows securely.", file=sys.stderr)
    return rows

def main():
    parser = argparse.ArgumentParser(description="Secure DSV Loader for Termux")
    parser.add_argument("file", help="Path to DSV file (TSV by default)")
    parser.add_argument("-d", "--delimiter", default="\t",
                        help="Delimiter (default: tab). Use commas with -d ','")
    parser.add_argument("-c", "--columns", type=int,
                        help="Expected number of columns (optional)")
    parser.add_argument("--no-data", action="store_true",
                        help="Only compute hash and verify structure, don't print data")
    args = parser.parse_args()

    try:
        rows = load_dsv(args.file, args.delimiter, args.columns)
        if not args.no_data:
            # Print first 5 rows as sample
            print("\n--- First 5 rows ---")
            for i, row in enumerate(rows[:5]):
                print(f"{i+1}\t{row}")
            if len(rows) > 5:
                print(f"... and {len(rows)-5} more rows.")
    except Exception as e:
        print(f"ERROR: {e}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()
