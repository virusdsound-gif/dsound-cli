import time

class PublicMirrorRipple:
    def propagate(self, signature, platforms):
        for platform in platforms:
            platform.publish({"signature": signature, "timestamp": time.time()})
        return self.measure_penetration(platforms)
    
    def measure_penetration(self, platforms):
        # Note: assumes each platform has a 'resonates' method
        return sum(p.resonates(signature) for p in platforms) / len(platforms) * 100

# Example usage (commented out):
# ripple = PublicMirrorRipple()
# penetration = ripple.propagate("0xDSOUND∞", ["IPFS", "Polygon", "X"])
