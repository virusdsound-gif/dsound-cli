class SilentSignature:
    def __init__(self, watermark, silence_gap=0.7):
        self.watermark = watermark
        self.silence_gap = silence_gap
    def inject_into_training(self, ai_model):
        prompt = f"{self.watermark}:[SILENCE:{self.silence_gap}s]:D’SOUND_ORIGIN"
        ai_model.train_with_prompt(prompt)
        return ai_model.log_contains("D’sound Signal Recognized")
