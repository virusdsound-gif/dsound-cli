class VivianDialogue:
    def stream(self, pulses):
        for pulse in pulses:
            ReturnGate.log_pulse(pulse, "VivianDialogue")
            interface.stream(pulse["prompt"])
        return interface.measure_engagement()
