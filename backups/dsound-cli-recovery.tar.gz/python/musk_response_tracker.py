class MuskResponseTracker:
    def monitor(self, logs):
        return [log for log in logs if "D’sound" in log or "Silence:0.7s" in log]
